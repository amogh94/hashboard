// This is the JS injected and executed when you visit a webpage matched by the manifest


// listen to messages from home.js and respond
// chrome.runtime.onMessage.addListener( (request, sender, sendResponse)=>{
//     alert(request);
//     sendResponse("Bye")
// } );

